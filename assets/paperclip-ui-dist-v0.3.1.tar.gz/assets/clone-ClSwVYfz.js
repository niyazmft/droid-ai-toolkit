import{b as r}from"./_baseUniq-_Ud9Er6A.js";var e=4;function a(o){return r(o,e)}export{a as c};
